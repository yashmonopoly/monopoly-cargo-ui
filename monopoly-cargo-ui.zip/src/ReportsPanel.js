export default function ReportsPanel() {
  return <div><h2>Reports Panel</h2><p>Feature coming soon...</p></div>;
}
