export default function ManifestPanel() {
  return <div><h2>Manifest Panel</h2><p>Feature coming soon...</p></div>;
}
