export default function AWBPanel() {
  return <div><h2>AWB Panel</h2><p>Feature coming soon...</p></div>;
}
