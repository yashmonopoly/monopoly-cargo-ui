export default function AccountsPanel() {
  return <div><h2>Accounts Panel</h2><p>Feature coming soon...</p></div>;
}
