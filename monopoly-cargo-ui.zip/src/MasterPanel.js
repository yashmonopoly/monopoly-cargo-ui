export default function MasterPanel() {
  return <div><h2>Master Panel</h2><p>Feature coming soon...</p></div>;
}
