export default function MISPanel() {
  return <div><h2>MIS Panel</h2><p>Feature coming soon...</p></div>;
}
