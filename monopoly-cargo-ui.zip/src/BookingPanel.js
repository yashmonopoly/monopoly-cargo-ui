export default function BookingPanel() {
  return <div><h2>Booking Panel</h2><p>Feature coming soon...</p></div>;
}
