export default function StockPanel() {
  return <div><h2>Stock Panel</h2><p>Feature coming soon...</p></div>;
}
